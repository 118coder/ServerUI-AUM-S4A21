using DfoServer.Game.Progression;
using DfoServer.Game.SelectCharacter;
using System;
using System.Collections.Generic;

namespace DfoServer.Game.Dungeon
{
    // Frozen settlement inputs and outputs for one participant. Retries reuse
    // this object so random rewards and irreversible grants are not recomputed.
    internal sealed class DungeonSettlementRuntime
    {
        internal bool IsTowerOfDespair;
        internal int TowerOfDespairFloor;
        internal bool ShouldScheduleCardRewardFlow;
        internal BloodAltar.BloodAltarParticipantSettlementRuntime BloodAltar;

        // Reward rank is server-owned. Presentation rank may be copied from a
        // validated SET_PLAY_RESULT field, but never feeds reward generation.
        internal byte ClientRankPoint;
        internal int PresentationRankPoint;
        internal byte PresentationRankGrade;
        internal int PresentationRankBonusIndex;
        internal int TimeBonusPoint;
        internal int RankPoint;
        internal byte RankGrade;
        internal int RankBonusIndex;

        internal uint ClearBaseExp;
        internal uint ScoreBonusExp;
        internal uint GrowthContractBonusExp;
        internal uint BlackDiamondBonusExp;
        internal uint AdventureGroupBonusExp;
        internal uint ClearBonusExp;
        internal uint ClearTotalExp;
        internal byte PreviousLevel;
        internal uint PreviousExp;
        internal ExperienceGrantResult ExperienceGrant;

        internal int DungeonLevel;
        internal int PaidCardCost;
        internal ClearRewardGenerator.CardReward FreeGold;
        internal ClearRewardGenerator.CardReward FreeItem;
        internal IReadOnlyList<ClearRewardGenerator.CardReward>
            TowerRewardCandidates = Array.Empty<ClearRewardGenerator.CardReward>();
        internal IReadOnlyList<TowerOfDespairGrantedReward>
            TowerGrantedRewards = Array.Empty<TowerOfDespairGrantedReward>();
        internal bool TowerRewardsGranted;

        // Dungeon permission is a persistent effect followed by a separate
        // client projection. Keeping the plan on the runtime lets a retry
        // resend the projection after the database write already succeeded.
        internal bool DungeonPermissionPlanReady;
        internal bool DungeonPermissionChanged;
        internal int DungeonPermissionAccountId;
        internal IReadOnlyList<DungeonPermissionEntrySnapshot>
            DungeonPermissionEntries = Array.Empty<DungeonPermissionEntrySnapshot>();

        internal uint MonsterTotalExp;
        internal uint BossTotalExp;
        internal uint ChampionTotalExp;
        internal uint SuperChampionTotalExp;
        internal uint NamedMonsterTotalExp;
        internal uint MonsterGrowthContractBonusExp;
        internal int ClearTimeMilliseconds;
    }
}
